var twentyfourhour = true; // true for 24 hr
var pad = false; // true to pad zero in hour
var IconSet = "Weather"; // choose your weather icon pack here
var value = "100"; // choose your size "100" 100% or "90" 90%  or "80" 80% or "70" 70% or  "60" 60%
