var twentyfourh = false; // true for 24 hr
var pad = false; // true to pad zero in hour
var IconSet = "Weather"; // choose your weather icon pack here
